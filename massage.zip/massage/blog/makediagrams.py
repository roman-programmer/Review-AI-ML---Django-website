from .models import Reviews
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import matplotlib
import matplotlib.pyplot as plt
from io import BytesIO
import base64
from django.db.models import Avg

matplotlib.use('Agg')  # безголовий режим

def make1():
# Збираємо статистику по відгуках
    positive_reviews = Reviews.objects.filter(rating__gte=5).count()
    negative_reviews = Reviews.objects.filter(rating__lt=5).count()

    # Створення стовпчикової діаграми
    labels = ['Позитивні', 'Негативні']
    counts = [positive_reviews, negative_reviews]

    fig, ax = plt.subplots()
    ax.bar(labels, counts, color=['springgreen', 'violet'])
    ax.set_title('Розподіл відгуків по позитивності')
    ax.set_xlabel('Тип відгуку')
    ax.set_ylabel('Кількість відгуків')

    # Перетворення графіку в зображення для передачі в шаблон
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    img_data_1 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()

    return img_data_1

def make2():
    # Отримуємо кількість відгуків для кожного рейтингу
    reviews_counts = [Reviews.objects.filter(rating=i).count() for i in range(1, 11)]

    # Створення стовпчикової діаграми
    labels = [str(i) for i in range(1, 11)]  # ['1', '2', ..., '10']
    colors = ['violet', 'pink', 'lightsalmon', 'khaki', 'yellow', 'paleturquoise', 'mediumaquamarine', 'seagreen', 'forestgreen', 'darkgreen']

    fig, ax = plt.subplots()
    ax.bar(labels, reviews_counts, color=colors)
    ax.set_title('Розподіл відгуків по оцінках')
    ax.set_xlabel('Оцінка')
    ax.set_ylabel('Кількість відгуків')

    # Перетворення графіку в зображення для передачі в шаблон
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    img_data_2 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()

    return img_data_2

def make3():
    reviews_by_date = Reviews.objects.values('date').annotate(avg_rating=Avg('rating')).order_by('date')

    dates = [entry['date'] for entry in reviews_by_date]
    avg_ratings = [entry['avg_rating'] for entry in reviews_by_date]

    fig, ax = plt.subplots()
    fig, ax = plt.subplots(figsize=(13, 5))  # Налаштовуємо розмір графіка

    ax.plot(dates, avg_ratings, marker='o', linestyle='-', color='blue')
    ax.set_title('Середня оцінка відгуків по днях')
    ax.set_xlabel('Дата')
    ax.set_ylabel('Середня оцінка')
    plt.xticks(rotation=25)

    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    img_data_3 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()

    return img_data_3
