from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Reviews
from .forms import CommentForm
from django.core.paginator import Paginator
from django.http import HttpResponse
from .models import News, Reviews
from django.contrib.auth.decorators import user_passes_test
from django.db.models import Avg
from .makediagrams import make1, make2, make3
from .aireviewmodel import get_ai_think

def home(request):
    return render(request, 'blog/home.html', {'title':'HowToMassage - Головна', 'firstwtxt': 'HowToMassage - найкращий помічник для досягнення твоєї мрії',})

def news(request):
    news_list = News.objects.all().order_by('-date')
    paginator = Paginator(news_list, 5)  # 5 коментарів на сторінку

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    data = {
        'news': News.objects.all(),
        'title': 'HowToMassage - Новини',
        'news': page_obj,
    }
    return render(request, 'blog/news.html', data)

def courses(request):
    return render(request, 'blog/courses.html', {'title':'HowToMassage - Курси'})

def reviews(request):
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('reviews')  # Redirect to the same page after a successful form submission
    else:
        form = CommentForm()

    comments_list = Reviews.objects.all().order_by('-date')
    paginator = Paginator(comments_list, 5)  # 5 коментарів на сторінку

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    data = {
        'title': 'HowToMassage - Відгуки',
        'firstwtxt': 'Відгуки',
        'comments': page_obj,
        'form': form,
    }

    return render(request, 'blog/reviews.html', data)

def contacts(request):
    return render(request, 'blog/contacts.html', {'title':'HowToMassage - Контакти'})

def admin_check(user):
    return user.is_authenticated and user.is_staff  # Дозволяє лише адміністраторам

@user_passes_test(admin_check)
def admin_diagrams(request):
    average_rating = round(Reviews.objects.aggregate(Avg('rating'))['rating__avg'], 2)
  
    img_data_1 = make1()
    img_data_2 = make2()
    img_data_3 = make3()
 
    reviews_with_predictions = get_ai_think()

    return render(request, 'blog/admin_diagrams.html', {
        'title': 'Адміністративна панель - Аналітика відгуків',
        'img_data_1': img_data_1,
        'img_data_2': img_data_2,
        'img_data_3': img_data_3,
        'reviews': reviews_with_predictions,
        'average_rating': average_rating,

    })

def post_detail(request, id):
    post = News.objects.get(id=id)
    return render(request, 'blog/post_detail.html', {'post': post})

def get_data_news(request):
    # Отримуємо новини з бази даних
    news = News.objects.all().values('title', 'text', 'date')
    
    # Формуємо рядок з інформацією з правильним кодуванням
    formatted_news = []
    for item in news:
        formatted_item = f"{{'title': '{item['title']}', 'text': '{item['text']}', 'date': '{item['date']}'}}"
        formatted_news.append(formatted_item)
    
    # Об'єднуємо всі елементи в один рядок з комами
    result = ', '.join(formatted_news)
    
    # Виводимо результат у відповідь
    return HttpResponse(f"[{result}]", content_type='text/plain; charset=utf-8')