from django import forms
from .models import Reviews
from .validators import validate_custom_phone_number

class CommentForm(forms.ModelForm):
    phone_number = forms.CharField(
        label='',
        validators=[validate_custom_phone_number],
        widget=forms.TextInput(attrs={'type': 'tel', 'placeholder': 'Ваш номер телефону (не буде відображатись на сайті)'}),
    )

    class Meta:
        model = Reviews
        fields = ['author', 'phone_number', 'text', 'rating']
        labels = {
            'author': '',
            'phone_number': '',
            'text': '',
            'rating': 'Оцініть нас',
        }
        widgets = {
            'author': forms.TextInput(attrs={'placeholder': 'Ваше ім\'я'}),
            'text': forms.Textarea(attrs={'placeholder': 'Що вам найбільше сподобалось?'}),
            'rating': forms.Select(choices=[(i, i) for i in range(1, 11)], attrs={'class': 'rating-dropdown'}),  # Оцінка від 1 до 10
        }
