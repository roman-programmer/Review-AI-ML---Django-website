from django.contrib import admin

# Register your models here.
from .models import News, Reviews
admin.site.register(News)
admin.site.register(Reviews)
