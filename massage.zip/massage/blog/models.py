import logging
from django.db import models
from django.utils import timezone
from phonenumber_field.modelfields import PhoneNumberField
import nlpcloud

class News(models.Model):
    class Meta:
        verbose_name = "Новина"
        verbose_name_plural="Новини"
    title = models.CharField("Назва статті", max_length=100)
    text = models.TextField("Основний текст")
    date = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return f"Новина: {self.title}"

logger = logging.getLogger(__name__)

class Reviews(models.Model):
    author = models.CharField("Автор", max_length=20)
    text = models.TextField("Відгук")
    phone_number = PhoneNumberField("Номер телефону")
    date = models.DateField(default=timezone.now)
    rating = models.PositiveIntegerField("Оцінка", choices=[(i, i) for i in range(1, 11)], default=5)  # Оцінка від 1 до 10

    admin_response = models.TextField("Відповідь адміністратора", blank=True, null=True)  # Поле для відповіді

    def check_unanswered_reviews():
        """Перевіряє відгуки без відповіді адміністратора та виводить у термінал."""
        unanswered_reviews = Reviews.objects.filter(admin_response__isnull=True)
        if unanswered_reviews.exists():
            logger.warning("Є відгуки без відповіді:")
            for review in unanswered_reviews:
                print(f"Відгук від {review.author} ({review.date}): {review.text}")
                client = nlpcloud.Client("finetuned-llama-3-70b", "...", gpu=True, lang="ukr_Cyrl")
                result = client.chatbot(
                    review.text, 
                    context="Це відгук, який людина залишила про портал з курсами для масажу. ШІ спокійний та чуйний. ШІ мусить дати відповідь від імені адміністратора. Якщо це хороший відгук - це для нас приємно, а якщо це поганий відгук - потрібно дати співчуття або вибачення, спитати у чому саме проблема якщо це не вказано та спитати як можна це вирішити. Якщо це не відгук а запитання, тоді потрібно сказати щоб людина звʼязалась з клієнтським менеджером через вкладку контакти. Не слід називати себе Інформація і не слід ставити слово Інформація на початок речення."
                )

                admin_response = result.get('response', 'Відповідь відсутня')
                print(f"Відповідь адміністратора: {admin_response}")

                # Оновлюємо поле admin_response у моделі Reviews
                review.admin_response = admin_response
                review.save()
                
        else:
            logger.info("Всі відгуки мають відповідь.")

    def __str__(self):
        return f"{self.author} в {self.date}"

    class Meta:
        verbose_name = "Відгук"
        verbose_name_plural = "Відгуки"
        
Reviews.check_unanswered_reviews()

