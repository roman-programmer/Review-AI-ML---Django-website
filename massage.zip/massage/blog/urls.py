from django.urls import path
from . import views

API_KEY_ROMAN = '12qw34er56ty'

urlpatterns = [
    path('', views.home, name='home'),
    path('news', views.news, name='news'),
    path('courses', views.courses, name='courses'),
    path('reviews', views.reviews, name='reviews'),
    path('contacts', views.contacts, name='contacts'),
    path('admin-diagrams', views.admin_diagrams, name='admin_diagrams'),
    path('post/<int:id>/', views.post_detail, name='post_detail'),
    path('get-data/news/'+API_KEY_ROMAN, views.get_data_news, name='get_data_news'),
]