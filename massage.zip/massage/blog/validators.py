from django.core.exceptions import ValidationError
from phonenumber_field.validators import validate_international_phonenumber

#Зміна тексту помилки

def validate_custom_phone_number(value):
    try:
        validate_international_phonenumber(value)
    except ValidationError:
        raise ValidationError('Введіть дійсний номер телефону (наприклад, +380501234567).')